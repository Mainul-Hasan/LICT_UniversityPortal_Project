﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for DataStudents
/// </summary>
public class DataStudents
{
    public string label { get; set; }
    public int value { get; set; }  
}